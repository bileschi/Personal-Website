function N = SymmetricPatchDotProduct(I,I2,options);
d.patchsize = 13;
options = ResolveMissingOptions(options,d);
ps = options.patchsize;
% I = I + TranslateIm(I,[0,1]);
N = zeros(size(I));
for dx = (1:ps)-ceil(ps/2)
 for dy = (1:ps)-ceil(ps/2)
  N = N + TranslateIm(I,[dy,dx]) .* TranslateIm(I2,[dy,-dx]);
 end
end
