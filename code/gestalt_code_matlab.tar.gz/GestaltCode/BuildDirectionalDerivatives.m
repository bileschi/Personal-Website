function cfilters = BuildDirectionalDerivatives(options)
% funciton cfilters = BuildDirectionalDerivatives(options)
%
%like directional gabor filters.

D.NOrientations = 18;
D.FilterResolution = 5;
D.FilterType = 'gabor';
D.sigma = 1;
D.aspect = 5;

if(nargin < 1), options = [];, end
options = ResolveMissingOptions(options,D);

for i = 1:options.NOrientations
  orientation(i) = pi * (i-1) / options.NOrientations;
  if(strcmpi(options.FilterType , 'gabor'))
    cfilters{i} = MakeGabor(options.FilterResolution,orientation(i),options.sigma,options.aspect);
  end
  if(strcmpi(options.FilterType , 'bar'))
    cfilters{i} = MakeBar(options.FilterResolution,orientation(i),options.sigma,options.aspect);
  end
end

function g = MakeGabor(r,o,s,a)
frequency = 4;
s = s*r;
g = zeros(r);
c = [r/2,r/2];
for i = 1:r
  y = i - c(2) - .5;
  for j = 1:r
    x = j-c(1) - .5;
    x2 = x*cos(o) - y*sin(o);
    y2 = x*sin(o) + y*cos(o);
    g(i,j) = exp(-(x2^2+a*y2^2)/(2*s)) *  sin(frequency*pi*y2/r);
  end
end

function g = MakeBar(r,o,s,a)
s = s*r;
g = zeros(r);
c = [r/2,r/2];
for i = 1:r
  y = i - c(2) - .5;
  for j = 1:r
    x = j-c(1) - .5;
    x2 = x*cos(o) - y*sin(o);
    y2 = x*sin(o) + y*cos(o);
    g(i,j) = exp(-(x2^2+a*y2^2)/(2*s)) * sign(y2);
  end
end
