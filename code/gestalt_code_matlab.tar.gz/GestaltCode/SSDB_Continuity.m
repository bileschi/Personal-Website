function saMat = SSDB_Continuity(X,options);
%an image representation which makes explicit the line segments

d.OrigSize = [128 128];
d.IncludeStageOne = 0;
d.MaxIterations = 6;
d.nUpperLimitFeatPerGroup = inf;  
if(nargin < 2), options = [];, end;
options = ResolveMissingOptions(options,d);

TotalSize = 18*prod(options.OrigSize);
sz = options.OrigSize;
here = pwd;
cd /cbcl/scratch01/bileschi/HoughTForm/m
DataRoot = '/cbcl/scratch01/bileschi/PrecomputedFeatures/StreetScenes/AppearanceDetector/';


if(options.IncludeStageOne)
  saMat.HStanLevel1 = zeros(prod(sz)*18 ,size(X,2));
end
sz = ceil(sz/2);
if(options.MaxIterations >= 2)
  saMat.HStanLevel2 = zeros(prod(sz)*18 ,size(X,2));
end
sz = ceil(sz/2);
if(options.MaxIterations >= 3)
  saMat.HStanLevel3 = zeros(prod(sz)*18 ,size(X,2));
end
sz = ceil(sz/2);
if(options.MaxIterations >= 4)
  saMat.HStanLevel4 = zeros(prod(sz)*18 ,size(X,2));
end
sz = ceil(sz/2);
if(options.MaxIterations >= 5)
  saMat.HStanLevel5 = zeros(prod(sz)*18 ,size(X,2));
end
sz = ceil(sz/2);
if(options.MaxIterations >= 6)
  saMat.HStanLevel6 = zeros(prod(sz)*18 ,size(X,2));
end
sz = ceil(sz/2);
for imgIdx = 1:size(X,2)
  fprintf('%d of %d \r',imgIdx, size(X,2));
  img = reshape(X(:,imgIdx),options.OrigSize);
  cHS = HStanMultiOrientation(img,options);
  if(options.IncludeStageOne)
    saMat.HStanLevel1(:,imgIdx) = cHS{1}(:);
  end
  if(options.MaxIterations >= 2)
    saMat.HStanLevel2(:,imgIdx) = cHS{2}(:);
  end
  if(options.MaxIterations >= 3)
    saMat.HStanLevel3(:,imgIdx) = cHS{3}(:);
  end
  if(options.MaxIterations >= 4)
    saMat.HStanLevel4(:,imgIdx) = cHS{4}(:);
  end
  if(options.MaxIterations >= 5)
    saMat.HStanLevel5(:,imgIdx) = cHS{5}(:);
  end
  if(options.MaxIterations >= 6)
    saMat.HStanLevel6(:,imgIdx) = cHS{6}(:);
  end
end
if(options.nUpperLimitFeatPerGroup)
  if(options.IncludeStageOne)
    if(size(saMat.HStanLevel1,1) > options.nUpperLimitFeatPerGroup)
      span = ceil(size(saMat.HStanLevel1,1)/options.nUpperLimitFeatPerGroup);
      saMat.HStanLevel1 = saMat.HStanLevel1(1:span:end,:);
    end
  end
  if(size(saMat.HStanLevel2,1) > options.nUpperLimitFeatPerGroup)
    span = ceil(size(saMat.HStanLevel2,1)/options.nUpperLimitFeatPerGroup);
    saMat.HStanLevel2 = saMat.HStanLevel2(1:span:end,:);
  end
  if(size(saMat.HStanLevel3,1) > options.nUpperLimitFeatPerGroup)
    span = ceil(size(saMat.HStanLevel3,1)/options.nUpperLimitFeatPerGroup);
    saMat.HStanLevel3 = saMat.HStanLevel3(1:span:end,:);
  end
  if(size(saMat.HStanLevel4,1) > options.nUpperLimitFeatPerGroup)
    span = ceil(size(saMat.HStanLevel4,1)/options.nUpperLimitFeatPerGroup);
    saMat.HStanLevel4 = saMat.HStanLevel4(1:span:end,:);
  end
  if(size(saMat.HStanLevel5,1) > options.nUpperLimitFeatPerGroup)
    span = ceil(size(saMat.HStanLevel5,1)/options.nUpperLimitFeatPerGroup);
    saMat.HStanLevel5 = saMat.HStanLevel5(1:span:end,:);
  end
  if(size(saMat.HStanLevel6,1) > options.nUpperLimitFeatPerGroup)
    span = ceil(size(saMat.HStanLevel6,1)/options.nUpperLimitFeatPerGroup);
    saMat.HStanLevel6 = saMat.HStanLevel6(1:span:end,:);
  end
end

fprintf('                               done\n');
cd(here);
