function [Symm,G] = Im2SymmIm(Im,options);
if(nargin < 2), options = [];, end
%Symmetry matrix GENERATION options
d.patchsize = 7;
d.LRrange = 15;
d.UDrange = 5;
d.permute = 1:size(Im,3);
d.reductionfactor = 1/(2^(1/3));


%Symmetry matrix REDUCTION options
d.ParaAxisMinFilterSpan = 8; 
d.PerpAxisMaxFilterSpan = 8; 
d.XYSize = [16,16]; % the target size in the xy directions
d.nScaleBands = 4;
options = ResolveMissingOptions(options,d);
options.IntermediateSize = [min(size(Im,1),128),min(size(Im,2),128)]


%%%%%%%%%%%%%
 n = 0;
 im_orig = Im;
 while(1);
   n = n+1;
   M{n} = clamp(AllRelativePatchNormXCorr_FlipPermute(Im,options),[0 1]);
   F{n} = sum(max(M{n},[],3).^2,4); % --> F is 2 dimensional now
   G(:,:,n) = imresize(F{n},options.IntermediateSize,'bilinear'); % --> G is three D (x,y,s);
   if(min([size(Im,1),size(Im,2)])*options.reductionfactor < 32)
     break;
   end
   Im = imresize(im_orig, options.reductionfactor^n,'bilinear');
 end
 Symm = -MatrixDecimate_Max(-G,1,options.ParaAxisMinFilterSpan,'max');
 Symm = MatrixDecimate_Max(Symm,2,options.ParaAxisMinFilterSpan,'max');
 newsize = [options.XYSize(2),options.XYSize(1), options.nScaleBands];
 Symm = genericResize(Symm,newsize);
 
%%%%%%%%%%%%%%%%%%%%%%%%%
