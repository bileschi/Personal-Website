function i = randomIntegers(n,M)
% returns a vector of n integers from 1 to M
p = rand(n,1);
i = ceil(M*p);
